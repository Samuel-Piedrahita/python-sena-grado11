-- Esquema de base de datos para el backend de Edunámica (SQL estándar; probado en estilo SQLite/PostgreSQL).
-- Hoy la web guarda todo en el navegador (localStorage). Este esquema es la base para migrarla a un servidor.

-- ===== Usuarios =====
CREATE TABLE schools (
  id            INTEGER PRIMARY KEY,
  name          TEXT NOT NULL UNIQUE,
  city          TEXT
);
CREATE TABLE users (
  id            TEXT PRIMARY KEY,
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,            -- usar bcrypt/argon2 en servidor, nunca texto plano
  created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE profiles (
  user_id       TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  name          TEXT NOT NULL,
  grade         INTEGER NOT NULL CHECK (grade IN (9,10,11)),
  school_id     INTEGER REFERENCES schools(id),
  goal_score    INTEGER NOT NULL DEFAULT 350 CHECK (goal_score BETWEEN 0 AND 500),
  exam_date     TEXT,
  avatar_color  TEXT NOT NULL DEFAULT '#336699',
  theme         TEXT NOT NULL DEFAULT 'auto'
);

-- ===== Contenido =====
CREATE TABLE areas (
  code   TEXT PRIMARY KEY,                -- mat, lec, soc, cie, ing
  name   TEXT NOT NULL,
  weight INTEGER NOT NULL,                -- peso en el puntaje global (3,3,3,3,1)
  color  TEXT NOT NULL
);
CREATE TABLE passages (
  id    TEXT PRIMARY KEY,
  body  TEXT NOT NULL
);
CREATE TABLE questions (
  id             TEXT PRIMARY KEY,
  area_code      TEXT NOT NULL REFERENCES areas(code),
  grade          INTEGER NOT NULL CHECK (grade IN (9,10,11)),
  difficulty     INTEGER NOT NULL CHECK (difficulty BETWEEN 1 AND 3),
  reference_year INTEGER NOT NULL,        -- año del examen Saber 11 de referencia (se muestra bajo la pregunta)
  passage_id     TEXT REFERENCES passages(id),
  statement      TEXT NOT NULL,
  explanation    TEXT NOT NULL,
  active         INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE question_options (
  question_id TEXT NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  position    INTEGER NOT NULL CHECK (position BETWEEN 0 AND 3),
  body        TEXT NOT NULL,
  is_correct  INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (question_id, position)
);
CREATE TABLE lessons (
  id        TEXT PRIMARY KEY,
  area_code TEXT NOT NULL REFERENCES areas(code),
  title     TEXT NOT NULL,
  minutes   INTEGER NOT NULL,
  body      TEXT NOT NULL
);
CREATE TABLE official_booklets (
  id        INTEGER PRIMARY KEY,
  year      TEXT NOT NULL,
  area_code TEXT REFERENCES areas(code),  -- NULL cuando el cuadernillo es por sesión
  session   TEXT,
  url       TEXT NOT NULL
);

-- ===== Progreso =====
CREATE TABLE attempts (
  id          INTEGER PRIMARY KEY,
  user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  question_id TEXT NOT NULL REFERENCES questions(id),
  chosen      INTEGER,                    -- NULL si se acabó el tiempo
  is_correct  INTEGER NOT NULL,
  mode        TEXT NOT NULL,              -- practice | daily | exam | tournament | diagnostic
  answered_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_attempts_user ON attempts(user_id, answered_at);
CREATE TABLE user_area_stats (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  area_code TEXT NOT NULL REFERENCES areas(code),
  skill_rating REAL NOT NULL DEFAULT 1050, -- sistema tipo Elo para la dificultad adaptativa
  correct INTEGER NOT NULL DEFAULT 0,
  total INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, area_code)
);
CREATE TABLE xp_events (
  id INTEGER PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  xp INTEGER NOT NULL,
  reason TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_xp_user_date ON xp_events(user_id, created_at);
CREATE TABLE user_wallet (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  coins INTEGER NOT NULL DEFAULT 20,
  streak INTEGER NOT NULL DEFAULT 0,
  best_streak INTEGER NOT NULL DEFAULT 0,
  last_active_day TEXT
);
CREATE TABLE badges (id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL, coins INTEGER NOT NULL);
CREATE TABLE user_badges (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  badge_id TEXT NOT NULL REFERENCES badges(id),
  earned_on TEXT NOT NULL,
  PRIMARY KEY (user_id, badge_id)
);
CREATE TABLE user_lessons (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  lesson_id TEXT NOT NULL REFERENCES lessons(id),
  completed_on TEXT NOT NULL,
  PRIMARY KEY (user_id, lesson_id)
);

-- ===== Retos, simulacros y torneos =====
CREATE TABLE daily_challenges (day TEXT PRIMARY KEY, question_ids TEXT NOT NULL);  -- JSON con 5 ids
CREATE TABLE user_daily (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  day TEXT NOT NULL REFERENCES daily_challenges(day),
  correct INTEGER NOT NULL,
  total INTEGER NOT NULL,
  PRIMARY KEY (user_id, day)
);
CREATE TABLE simulations (
  id INTEGER PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  questions INTEGER NOT NULL,
  correct INTEGER NOT NULL,
  minutes_used INTEGER NOT NULL,
  estimated_score INTEGER NOT NULL        -- 0 a 500
);
CREATE TABLE tournaments (id INTEGER PRIMARY KEY, kind TEXT NOT NULL, starts_at TEXT NOT NULL, ends_at TEXT NOT NULL);
CREATE TABLE tournament_entries (
  tournament_id INTEGER NOT NULL REFERENCES tournaments(id),
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  points INTEGER NOT NULL,
  PRIMARY KEY (tournament_id, user_id)
);

-- ===== Plan de estudio =====
CREATE TABLE study_plan_prefs (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  minutes_per_day INTEGER NOT NULL DEFAULT 60,
  study_days TEXT NOT NULL DEFAULT '0,1,2,3,4'   -- 0 = lunes
);
CREATE TABLE plan_checks (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  block_id TEXT NOT NULL,
  done_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, block_id)
);

-- ===== Ranking semanal (vista) =====
-- Cambia la fecha de inicio de semana por la del lunes actual al consultar.
CREATE VIEW weekly_ranking AS
SELECT p.user_id, p.name, s.name AS school, SUM(x.xp) AS xp
FROM xp_events x
JOIN profiles p ON p.user_id = x.user_id
LEFT JOIN schools s ON s.id = p.school_id
WHERE x.created_at >= date('now','weekday 1','-7 days')
GROUP BY p.user_id
ORDER BY xp DESC;
