/* Componentes compartidos entre páginas: medidor, mapa de constancia, misiones y ranking */
function gauge(score,goal){
  const L=282.7;
  return`<div class="gauge"><svg viewBox="0 0 220 130" role="img" aria-label="Puntaje estimado ${score} de 500, meta ${goal}">
   <path class="g-track" d="M20 112 A90 90 0 0 1 200 112" fill="none" stroke-width="16" stroke-linecap="round" pathLength="100"/>
   <path class="g-fill" d="M20 112 A90 90 0 0 1 200 112" fill="none" stroke-width="16" stroke-linecap="round" pathLength="100" stroke-dasharray="${clamp(score/5,1,100)} 100"/>
   </svg><div class="num"><b>${score}</b><span>Meta: ${goal}</span></div></div>`;
}
const accAll=()=>{const t=total();return t?Math.round(AREA_KEYS.reduce((n,a)=>n+S.stats[a].c,0)/t*100):0};
function heat(){
  const ws=weekStart(),start=addDays(ws,-28),cells=[];
  for(let i=0;i<35;i++){const d=addDays(start,i),k=dayKey(d),n=S.days[k]||0;const f=d>new Date();
    cells.push(`<i class="${n>=15?'l3':n>=5?'l2':n>0?'l1':''} ${k===dayKey()?'today':''}" title="${k}: ${n} preguntas" ${f?'style="opacity:.35"':''}></i>`)}
  return`<div class="heat" role="img" aria-label="Mapa de constancia">${cells.join('')}</div>`;
}
function spark(vals){
  const w=300,h=70,mx=Math.max(...vals,1),mn=Math.min(...vals,0),r=(mx-mn)||1;
  const pts=vals.map((v,i)=>[(i/(vals.length-1))*(w-16)+8,h-8-((v-mn)/r)*(h-16)]);
  return`<svg viewBox="0 0 ${w} ${h}" width="100%" style="max-width:360px;display:block" role="img" aria-label="Puntajes de simulacros: ${vals.join(', ')}"><polyline fill="none" stroke="var(--brand)" stroke-width="3" stroke-linejoin="round" stroke-linecap="round" points="${pts.map(p=>p.join(',')).join(' ')}"/>${pts.map(p=>`<circle cx="${p[0]}" cy="${p[1]}" r="4" fill="var(--lime)" stroke="var(--brand)" stroke-width="2"/>`).join('')}</svg>`;
}
function missionList(){
  const w=wc();
  return[{id:'q',t:'Responde 30 preguntas',v:w.q,g:30,r:15},{id:'d',t:'Completa 3 retos diarios',v:w.d,g:3,r:20},{id:'s',t:'Termina 1 simulacro',v:w.s,g:1,r:25},{id:'x',t:'Suma 300 XP esta semana',v:weeklyXP(),g:300,r:20}];
}
function missionHTML(m){
  const w=wc(),done=m.v>=m.g,cl=w.claimed[m.id];
  return`<div class="mission"><div><b>${m.t}</b><br><small>${Math.min(m.v,m.g)} de ${m.g}. Premio: ${m.r} monedas</small></div>${cl?`<span class="tag">Reclamada</span>`:done?`<button class="btn lime sm" data-claim="${m.id}">Reclamar</button>`:`<span class="muted">${Math.round(Math.min(m.v,m.g)/m.g*100)}%</span>`}<div class="bar"><i style="width:${Math.min(m.v/m.g,1)*100}%"></i></div></div>`;
}
function claim(id,el,redraw){
  const m=missionList().find(x=>x.id===id),w=wc();if(!m||w.claimed[id]||m.v<m.g)return;
  w.claimed[id]=1;S.coins+=m.r;save();updateChips();toast(`${ic('coin',18)} +${m.r} monedas`,'good');redraw&&redraw();
}

function botsFor(){
  const me=S.user&&S.user.school?S.user.school.trim():'';
  return BOTS.map((b,i)=>({n:b[0],city:b[1],school:(me&&i%4===0)?me:BOT_SCHOOLS[i%BOT_SCHOOLS.length],c:['#336699','#2F8F83','#D9902F','#5FAE4A','#8B6BC7','#D9583A'][i%6]}));
}
function botWeekly(b,wk,frac){const r=rng(hash(b.n+wk));return Math.round((60+r()*820)*frac)}
function leaderboard(tab,wk=weekKey(),frac){
  if(frac==null)frac=clamp(((new Date().getDay()+6)%7+1)/7,.15,1);
  const u=S.user;let rows;
  if(tab==='all')rows=botsFor().map(b=>({...b,x:Math.round(1200+rng(hash(b.n+'all'))()*9000)}));
  else rows=botsFor().map(b=>({...b,x:botWeekly(b,wk,frac)}));
  if(tab==='col'){const me=(u.school||'').trim();rows=me?rows.filter(r=>r.school===me):[]}
  rows.push({n:u.name,city:'',school:u.school||'Sin colegio',c:u.color,x:tab==='all'?S.xp:weeklyXP(wk),me:true});
  return rows.sort((a,b)=>b.x-a.x);
}
function settleCup(){
  if(!S.user)return;const pw=weekKey(addDays(new Date(),-7));
  if(S.cups.some(c=>c.wk===pw)||(S.wk[pw]||0)<=0)return;
  const pos=leaderboard('sem',pw,1).findIndex(r=>r.me)+1;
  const coins=pos===1?50:pos===2?30:pos===3?20:pos<=10?10:0;
  S.cups.push({wk:pw,pos});S.coins+=coins;save();
  setTimeout(()=>toast(`${ic('trophy',18)} Cerró la Copa de la semana pasada. Quedaste en el puesto ${pos}${coins?`, +${coins} monedas`:''}.`,'good',5500),600);
}

