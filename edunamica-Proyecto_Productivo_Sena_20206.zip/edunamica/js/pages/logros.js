/* Página: logros.html */
function badgesV(el){
  const got=BADGES.filter(b=>S.badges[b.id]).length;
  el.innerHTML=head('Logros',`Has desbloqueado ${got} de ${BADGES.length}. Cada logro te da monedas para pistas.`)+`
   <div class="cols3" style="margin-bottom:18px"><div class="card flat"><div class="kv"><div><b>${lvl(S.xp)}</b><span>Nivel</span></div><div><b>${fmt(S.xp)}</b><span>XP total</span></div></div><div class="bar" style="margin-top:12px"><i style="width:${lvlPct()}%"></i></div></div>
   <div class="card flat"><div class="kv"><div><b>${S.coins}</b><span>Monedas</span></div><div><b>${streakNow()}</b><span>Racha actual</span></div></div></div>
   <div class="card flat"><div class="kv"><div><b>${total()}</b><span>Preguntas</span></div><div><b>${accAll()}%</b><span>Aciertos</span></div></div></div></div>
   <div class="badges">${BADGES.map(b=>{const g=S.badges[b.id];return`<div class="badge ${g?'':'lock'}"><span class="ico">${ic(g?'medal':'lock',22)}</span><b>${b.n}</b><small>${b.d}</small><small>${g?'Obtenido el '+g:'Premio: '+b.coin+' monedas'}</small></div>`}).join('')}</div>`;
}


mountPage('logros',badgesV);
