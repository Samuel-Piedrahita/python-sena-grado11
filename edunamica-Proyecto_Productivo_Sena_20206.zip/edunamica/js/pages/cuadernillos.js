/* Página: cuadernillos.html */
function cuadV(el){
  const yrs=Object.keys(CUAD).sort((a,b)=>b-a);
  el.innerHTML=head('Cuadernillos oficiales','Pruebas Saber 11 de años anteriores. Resuélvelas después de practicar aquí para medir tu avance con el formato real.')+`
   <div class="banner">${ic('doc',26)}<div class="grow"><b>Cómo usarlos</b><p class="muted">Practica un área en Edunámica, luego resuelve el mismo año y área en el cuadernillo. Revisa cada error y guárdalo en tu repaso.</p></div></div>
   <div class="cols2">${CUAD_SES.length?`<section class="card"><h3>2024 y 2025, por sesión</h3><div class="cuad">${CUAD_SES.map(([y,t,u])=>`<a class="dl" href="${u}" target="_blank" rel="noopener noreferrer"><span><b>${y}</b>, ${t}</span>${ic('arrow',18)}</a>`).join('')}</div></section>`:''}
   ${yrs.map(y=>`<section class="card"><h3>${y}, por área</h3><div class="cuad">${AREA_KEYS.map(a=>`<a class="dl" style="--ac:${AREAS[a].c}" href="${CUAD[y][a]}" target="_blank" rel="noopener noreferrer"><span><i></i>${AREAS[a].n}</span>${ic('arrow',18)}</a>`).join('')}</div></section>`).join('')}</div>
   <p class="muted" style="margin-top:16px;font-size:.9rem">Los cuadernillos son material oficial del ICFES. Los enlaces provienen del índice de Univérsate, un sitio sin relación con el ICFES, y se abren en una pestaña nueva. Si alguno no carga, búscalo en la página oficial del ICFES.</p>`;
}


mountPage('cuadernillos',cuadV);
