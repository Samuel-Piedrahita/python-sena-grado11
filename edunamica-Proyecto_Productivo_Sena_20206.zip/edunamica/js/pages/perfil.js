/* Página: perfil.html */
const COLS=['#336699','#2F8F83','#D9902F','#5FAE4A','#8B6BC7','#D9583A'];
function profileV(el){
  const u=S.user;let grade=u.grade,color=u.color;
  el.innerHTML=head('Perfil','Tus datos, tus preferencias y tu cuenta.')+`
  <div class="cols2">
   <section class="card"><div class="row">${avatar(u.name,u.color,64)}<div><h3 style="margin:0">${esc(u.name)}</h3><p class="muted">${esc(u.email||'')}</p><p class="muted">Grado ${u.grade}${u.school?', '+esc(u.school):''}</p></div></div>
    <div class="kv" style="margin-top:16px"><div><b>${u.goal}</b><span>Meta</span></div><div><b>${globalScore()}</b><span>Estimado</span></div><div><b>${u.exam||'Sin fecha'}</b><span>Examen</span></div></div></section>
   <section class="card"><h3>Preferencias y sesión</h3><div class="field"><span class="lab" id="tl">Tema</span><div class="seg" role="group" aria-labelledby="tl">${[['auto','Automático'],['light','Claro'],['dark','Oscuro']].map(([k,l])=>`<button data-th="${k}" aria-pressed="${S.theme===k}">${l}</button>`).join('')}</div></div>
    <div class="row"><button class="btn ghost" id="lo">Cerrar sesión</button></div></section></div>
  <section class="card" id="editar" style="margin-top:16px"><h3>Editar perfil</h3><form id="pf" novalidate>
   <div class="cols2"><div class="field"><label for="name">Nombre</label><input type="text" id="name" maxlength="40" value="${esc(u.name)}"></div>
   <div class="field"><label for="email">Correo</label><input type="text" id="email" value="${esc(u.email||'')}"></div></div>
   <div class="cols2"><div class="field"><label for="school">Colegio</label><input type="text" id="school" maxlength="50" value="${esc(u.school||'')}"></div>
   <div class="field"><label for="exam">Fecha del examen</label><input type="date" id="exam" value="${u.exam||''}"></div></div>
   <div class="cols2"><div class="field"><span class="lab" id="gl">Grado</span><div class="seg" role="group" aria-labelledby="gl">${[9,10,11].map(g=>`<button type="button" data-g="${g}" aria-pressed="${g===u.grade}">Grado ${g}</button>`).join('')}</div></div>
   <div class="field"><label for="goal">Meta: <b id="gv">${u.goal}</b> de 500</label><input type="range" id="goal" min="200" max="500" step="5" value="${u.goal}"></div></div>
   <div class="field"><span class="lab" id="cl">Color del avatar</span><div class="swatches" role="group" aria-labelledby="cl">${COLS.map((c,i)=>`<button type="button" style="--c:${c}" data-c="${c}" aria-label="Color ${i+1}" aria-pressed="${c===u.color}"></button>`).join('')}</div></div>
   <p class="err" id="perr" role="alert"></p><button class="btn lime">Guardar cambios</button></form></section>
  <div class="cols2" style="margin-top:16px">
   <section class="card"><h3>Cambiar contraseña</h3><form id="cp" novalidate><div class="field"><label for="op">Contraseña actual</label><div class="pw-wrap"><span class="input-icon">${ic('lock',18)}</span><input type="password" id="op" autocomplete="current-password"><button type="button" class="pw-toggle-btn" id="pw-t-op" aria-label="Mostrar contraseña"><span class="pw-icon-eye">${ic('eye',18)}</span></button></div></div>
    <div class="field"><label for="np">Nueva contraseña</label><div class="pw-wrap"><span class="input-icon">${ic('lock',18)}</span><input type="password" id="np" autocomplete="new-password"><button type="button" class="pw-toggle-btn" id="pw-t-np" aria-label="Mostrar contraseña"><span class="pw-icon-eye">${ic('eye',18)}</span></button></div><small>Mínimo 6 caracteres.</small></div><p class="err" id="cerr" role="alert"></p><button class="btn">Actualizar</button></form></section>
   <section class="card"><h3>Zona de riesgo</h3><p class="muted" style="margin-bottom:12px">Estas acciones no se pueden deshacer.</p>
    <div class="stack"><button class="btn ghost" id="reset" style="color:var(--coral);border-color:var(--coral)">Borrar mi progreso</button><button class="btn ghost" id="del" style="color:var(--coral);border-color:var(--coral)">Eliminar mi cuenta</button></div></section></div>`;
  $$('[data-g]',el).forEach(b=>b.onclick=()=>{grade=+b.dataset.g;$$('[data-g]',el).forEach(x=>x.setAttribute('aria-pressed',x===b))});
  $$('[data-c]',el).forEach(b=>b.onclick=()=>{color=b.dataset.c;$$('[data-c]',el).forEach(x=>x.setAttribute('aria-pressed',x===b))});
  $('#goal',el).oninput=e=>$('#gv',el).textContent=e.target.value;
  const setupPw=(btnId,inpId)=>{const b=$(btnId,el),i=$(inpId,el);if(b&&i){let s=false;b.onclick=()=>{s=!s;i.type=s?'text':'password';b.innerHTML=s?ic('eyeOff',18):ic('eye',18)}}};
  setupPw('#pw-t-op','#op');setupPw('#pw-t-np','#np');
  $$('[data-th]',el).forEach(b=>b.onclick=()=>{S.theme=b.dataset.th;applyTheme();save();profileV(el)});
  $('#lo',el).onclick=logout;
  $('#pf',el).onsubmit=e=>{
    e.preventDefault();const err=$('#perr',el),name=$('#name',el).value.trim(),email=$('#email',el).value.trim();
    if(name.length<2){err.textContent='Escribe tu nombre.';return}
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){err.textContent='Escribe un correo válido.';return}
    if(getUsers().some(x=>x.email===normEmail(email)&&x.id!==store.get(SESSION_KEY))){err.textContent='Ese correo ya pertenece a otra cuenta.';return}
    saveProfile({name,email,grade,color,school:$('#school',el).value.trim(),goal:+$('#goal',el).value,exam:$('#exam',el).value});
    toast('Perfil actualizado','good');location.href='perfil.html';
  };
  $('#cp',el).onsubmit=async e=>{
    e.preventDefault();const err=$('#cerr',el),np=$('#np',el).value;err.textContent='';
    if(np.length<6){err.textContent='La nueva contraseña debe tener al menos 6 caracteres.';return}
    const r=await changePassword($('#op',el).value,np);
    if(r.error){err.textContent=r.error;return}
    toast('Contraseña actualizada','good');$('#op',el).value='';$('#np',el).value='';
  };
  $('#reset',el).onclick=()=>confirmBox('¿Borrar todo tu progreso? Tu cuenta se conserva.','Sí, borrar',()=>{const p=S.user;S=fresh();S.user=p;save();location.href='dashboard.html'});
  $('#del',el).onclick=()=>confirmBox('¿Eliminar tu cuenta y todos tus datos?','Sí, eliminar',deleteAccount);
  if(location.hash==='#editar'){const t=$('#editar',el);t&&t.scrollIntoView()}
}
mountPage('perfil',profileV);
