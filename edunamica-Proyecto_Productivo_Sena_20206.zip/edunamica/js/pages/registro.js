/* Página: registro.html */
(function(){
  const COL=['#336699','#2F8F83','#D9902F','#5FAE4A','#8B6BC7','#D9583A'];
  const root=$('#root');let grade=11,color=COL[0];
  root.innerHTML=`<div class="auth"><div class="auth-side">${logo('index.html')}
   <div><h2>Cuéntanos de ti y arrancamos</h2><p style="margin-top:12px">Con estos datos adaptamos la dificultad, armamos tu plan y te ubicamos en el ranking de tu colegio.</p></div>
   <p style="font-size:.9rem">Tu progreso se guarda en este dispositivo.</p></div>
   <div class="auth-form"><form id="f" novalidate>
    <h1 style="font-size:2rem;margin-bottom:18px">Crear mi perfil</h1>
    <div class="field"><label for="name">Tu nombre</label><input type="text" id="name" maxlength="40" autocomplete="name" placeholder="Ej: Valentina Ríos"></div>
    <div class="field"><label for="email">Correo</label><div class="input-wrap"><span class="input-icon">${ic('user',18)}</span><input type="email" id="email" inputmode="email" autocomplete="email" placeholder="tucorreo@ejemplo.com"></div></div>
    <div class="field"><label for="pw">Contraseña</label><div class="pw-wrap"><span class="input-icon">${ic('lock',18)}</span><input type="password" id="pw" autocomplete="new-password" placeholder="Mínimo 6 caracteres"><button type="button" class="pw-toggle-btn" id="pw-toggle-reg" aria-label="Mostrar contraseña"><span class="pw-icon-eye">${ic('eye',18)}</span></button></div><small>Mínimo 6 caracteres.</small></div>
    <div class="field"><span class="lab" id="gl">Tu grado</span><div class="seg" role="group" aria-labelledby="gl">${[9,10,11].map(g=>`<button type="button" data-g="${g}" aria-pressed="${g===11}">Grado ${g}</button>`).join('')}</div></div>
    <div class="field"><label for="school">Tu colegio</label><input type="text" id="school" maxlength="50" placeholder="Ej: I.E. Francisco José de Caldas"></div>
    <div class="field"><label for="goal">Puntaje que quieres lograr: <b id="gv">350</b> de 500</label><input type="range" id="goal" min="200" max="500" step="5" value="350"></div>
    <div class="field"><label for="exam">Fecha de tu examen <span class="muted">(opcional)</span></label><input type="date" id="exam"><small>Si la sabes, ajustamos tu plan por fases.</small></div>
    <div class="field"><span class="lab" id="cl">Color de tu avatar</span><div class="swatches" role="group" aria-labelledby="cl">${COL.map((c,i)=>`<button type="button" style="--c:${c}" data-c="${c}" aria-label="Color ${i+1}" aria-pressed="${i===0}"></button>`).join('')}</div></div>
    <p class="err" id="err" role="alert"></p>
    <button class="btn lime lg" style="width:100%" id="go">Crear mi perfil</button>
    <p class="muted" style="margin-top:16px">¿Ya tienes cuenta? <a href="login.html">Iniciar sesión</a></p>
    <p style="margin-top:8px"><a href="index.html">Volver al inicio</a></p></form></div></div>`;
  $$('[data-g]',root).forEach(b=>b.onclick=()=>{grade=+b.dataset.g;$$('[data-g]',root).forEach(x=>x.setAttribute('aria-pressed',x===b))});
  $$('[data-c]',root).forEach(b=>b.onclick=()=>{color=b.dataset.c;$$('[data-c]',root).forEach(x=>x.setAttribute('aria-pressed',x===b))});
  $('#goal').oninput=e=>$('#gv').textContent=e.target.value;
  const pwt=$('#pw-toggle-reg'),pwi=$('#pw');
  if(pwt&&pwi){let s=false;pwt.onclick=()=>{s=!s;pwi.type=s?'text':'password';pwt.innerHTML=s?ic('eyeOff',18):ic('eye',18)}}
  $('#f').onsubmit=async e=>{
    e.preventDefault();const err=$('#err'),go=$('#go');err.textContent='';
    const name=$('#name').value.trim(),email=$('#email').value.trim(),pw=$('#pw').value;
    if(name.length<2){err.textContent='Escribe tu nombre.';$('#name').focus();return}
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){err.textContent='Escribe un correo válido.';$('#email').focus();return}
    if(pw.length<6){err.textContent='La contraseña debe tener al menos 6 caracteres.';$('#pw').focus();return}
    go.disabled=true;
    const r=await registerUser({name,email,grade,school:$('#school').value.trim(),goal:+$('#goal').value,exam:$('#exam').value,color},pw);
    go.disabled=false;
    if(r.error){err.textContent=r.error;return}
    location.href='dashboard.html';
  };
})();
