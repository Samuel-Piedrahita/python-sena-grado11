/* Página: torneos.html */
function tourField(){const r=rng(hash('tour'+dayKey()));return BOTS.slice(0,24).map(b=>({n:b[0],s:Math.round(350+r()*900)}))}
function tourV(el,arg){
  const today=dayKey(),mine=S.tour[today];
  if(arg==='jugar'){
    const play=()=>runLearn(el,{title:'Torneo relámpago',qs:pickSet(10,{}),timer:20,k:20,hints:false,back:'torneos.html',again:play,onEnd:r=>{
      const field=tourField(),all=[...field,{n:'Tú',s:r.tp,me:true}].sort((a,b)=>b.s-a.s),pos=all.findIndex(x=>x.me)+1;
      let note='Tu mejor marca de hoy se mantiene.';
      if(!mine||r.tp>mine.pts){S.tour[today]={pts:r.tp,pos};}
      if(!mine){const coins=pos<=3?40:pos<=10?20:10;S.coins+=coins;addXP(pos<=3?60:30);note=`Premio de hoy: ${coins} monedas.`;checkBadges();save()}
      return`<div class="card" style="width:100%;text-align:left"><h3>Puesto ${pos} de ${all.length}, ${r.tp} puntos</h3><p class="muted" style="margin-bottom:8px">${note} Cada acierto suma 100 puntos más 5 por segundo que sobre.</p><table class="rank"><tbody>${all.slice(0,8).map((x,k)=>`<tr class="${x.me?'me':''}"><td class="pos">${k+1}</td><td>${esc(x.n)}</td><td style="text-align:right">${x.s}</td></tr>`).join('')}</tbody></table></div>`}});
    return play();
  }
  const ms=weekStart(),endIn=Math.ceil((addDays(ms,7)-new Date())/36e5);
  const pos=leaderboard('sem').findIndex(r=>r.me)+1;
  el.innerHTML=head('Torneos','Mide tu velocidad y tu precisión contra otros jugadores.')+`
   <div class="cols2"><div class="tourc live"><span class="tag live">Disponible hoy</span><h3>Torneo relámpago</h3><p class="muted">Diez preguntas, 20 segundos para cada una. Gana puntos por acertar y por rapidez.</p>${mine?`<p><b>Tu mejor marca de hoy:</b> ${mine.pts} puntos, puesto ${mine.pos}.</p>`:''}<a class="btn lime" href="torneos.html?a=jugar">${mine?'Jugar otra vez':'Entrar al torneo'}</a><small class="muted">El premio se entrega la primera vez que juegas cada día.</small></div>
    <div class="tourc"><span class="tag">Semanal</span><h3>Copa Edunámica</h3><p class="muted">Gana quien más XP acumule de lunes a domingo. Al cierre, el top 3 recibe 50, 30 y 20 monedas y el top 10 suma 10.</p><p><b>Vas en el puesto ${pos}.</b> Cierra en ${endIn>=24?Math.floor(endIn/24)+' días':endIn+' h'}.</p><a class="btn ghost" href="ranking.html">Ver clasificación</a></div>
    <div class="tourc"><span class="tag">Próximamente</span><h3>Copa entre colegios</h3><p class="muted">Cada colegio suma el XP de sus estudiantes. Pensado para alianzas con instituciones educativas.</p></div>
    <div class="tourc"><span class="tag">Historial</span><h3>Tus copas</h3>${S.cups.length?S.cups.slice(-4).reverse().map(c=>`<p>Semana del ${c.wk}: puesto ${c.pos}</p>`).join(''):'<p class="muted">Cuando cierre una semana en la que sumes XP, tu puesto aparecerá aquí.</p>'}</div></div>`;
}

mountPage('torneos',tourV);
