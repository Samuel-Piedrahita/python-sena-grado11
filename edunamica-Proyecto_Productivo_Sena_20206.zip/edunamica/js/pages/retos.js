/* Página: retos.html */
function dailyV(el,arg){
  const today=dayKey(),done=S.daily.date===today;
  if(arg==='jugar'&&!done){
    return runLearn(el,{title:'Reto diario completado',qs:dailySet(),back:'retos.html',hints:true,onEnd:r=>{
      const bonus=50+r.ok*10;S.daily={date:today,ok:r.ok,total:r.total};S.dailyCount++;wc().d++;addXP(bonus);S.coins+=10;checkBadges();save();
      return`<div class="card flat" style="width:100%"><b>Bonus del reto: +${bonus} XP y +10 monedas</b><p class="muted">Vuelve mañana para mantener tu racha de ${streakNow()} días.</p></div>`}});
  }
  const midnight=new Date();midnight.setHours(24,0,0,0);const hrs=Math.ceil((midnight-new Date())/36e5);
  const missions=missionList();
  el.innerHTML=head('Retos diarios','Un reto nuevo cada día y misiones semanales para ganar monedas.')+`
   <div class="cols2"><div class="card ${done?'':'big-cta'}">${done?`<h3>Reto de hoy completado</h3><p>Acertaste ${S.daily.ok} de ${S.daily.total}. El próximo reto está disponible en unas ${hrs} horas.</p><div class="row" style="margin-top:12px">${AREA_KEYS.map(a=>`<span class="pill" style="--ac:${AREAS[a].c}">${AREAS[a].n.split(' ')[0]}</span>`).join('')}</div>`:`<h3 style="color:#fff">Reto del día</h3><p>Cinco preguntas, una por área. Te damos 50 XP de bonus por terminarlo y 10 por cada acierto.</p><a class="btn lime" href="retos.html?a=jugar">Jugar ahora</a>`}</div>
    <div class="card"><h3>Tu racha</h3><div class="kv"><div><b>${streakNow()}</b><span>Días seguidos</span></div><div><b>${S.best}</b><span>Mejor racha</span></div><div><b>${S.dailyCount}</b><span>Retos completados</span></div></div><p class="muted" style="margin-top:12px">Responde al menos una pregunta cada día para no perderla.</p></div></div>
   <div class="cols2" style="margin-top:16px"><div class="card"><h3>Misiones de la semana</h3>${missions.map(missionHTML).join('')}</div><div class="card"><h3>Calendario de constancia</h3>${heat()}<p class="muted" style="margin-top:12px;font-size:.9rem">Cada cuadro es un día. Más verde significa más preguntas respondidas.</p></div></div>`;
  $$('[data-claim]',el).forEach(b=>b.onclick=()=>claim(b.dataset.claim,el,()=>dailyV(el)));
}


mountPage('retos',dailyV);
